# Upgrade Plan: imfundo-kahle (20260831150852)

- **Generated**: 2026-08-31 15:08:52
- **HEAD Branch**: master
- **HEAD Commit ID**: N/A

## Available Tools

**JDKs**
- JDK 17: not available (baseline will be skipped)
- JDK 21: C:\Program Files\Java\jdk-21\bin (available on host, not the final target)
- JDK 25: **<TO_BE_INSTALLED>** (required by final target)

**Build Tools**
- Maven: **<TO_BE_INSTALLED>** (no Maven installation detected; project is Maven-based)
- Maven Wrapper: not present in repository root

## Guidelines

- Upgrade the Java runtime to the latest LTS version supported by the project: Java 25.
- Keep the application compiling and testing successfully after the runtime upgrade.
- Prefer minimal, compatibility-focused changes; do not introduce unrelated framework migrations.
- Use Maven for build verification throughout the upgrade.

> Note: You can add any specific guidelines or constraints for the upgrade process here if needed, bullet points are preferred.

## Options

- Working branch: appmod/java-upgrade-20260831150852
- Run tests before and after the upgrade: true

## Upgrade Goals

- Java 25

## Technology Stack

| Technology/Dependency | Current | Min Compatible Version | Why Incompatible |
| ---------------------- | ------- | ---------------------- | ---------------- |
| Java | 17 | 25 | User requested Java 25 LTS target |
| Spring Boot | 3.3.4 | 3.5.0 | Java 25 compatibility requires a modern Spring Boot line; Boot 3.3.x is the current baseline but may need a compatible managed release for the target runtime |
| Maven | not installed | 3.9.0+ | Java 25 support requires a modern Maven runtime; no Maven installation was detected |
| Spring Boot Maven plugin | managed by parent | current Boot-managed | Must be validated against Java 25 and the selected Boot version |
| Spring Security | 6.x (managed by Boot) | 6.x | Compatible with Spring Boot 3.5; no direct migration required unless build errors appear |

## Derived Upgrades

- Java 25 target requires a modern Java toolchain and Maven 3.9+.
- Spring Boot 3.3.x is already on the Spring 6 / Jakarta 10 line; a minor Boot version bump to 3.5.x is a reasonable compatibility bridge for the Java 25 runtime target.
- No Kotlin usage detected in this repository; no Kotlin version bump is required.
- No Jakarta namespace rewrite is required because the project already uses Spring Boot 3.3.x and Spring Security 6.

## Impact Analysis

### Subsection: Dependency Changes

| File | Dependency | Current | Action | Target | Reason |
|------|-----------|---------|--------|--------|--------|
| pom.xml | java.version | 17 | upgrade | 25 | User requested latest LTS Java target |
| pom.xml | org.springframework.boot:spring-boot-starter-parent | 3.3.4 | upgrade | 3.5.x | Compatibility bridge for Java 25 runtime support |
| pom.xml | build plugins / Maven lifecycle | unmanaged | validate | current Boot-managed | Ensure Maven and Spring Boot plugin versions support Java 25 |

### Subsection: Source Code Changes

| File | Location | Current | Required Change | Reason |
|------|----------|---------|----------------|--------|
| None identified | project-wide | Java 17 and Boot 3.3 baseline | No source-level edits expected for a pure JDK runtime bump; only build metadata and compatibility checks if the compiler/runtime rejects the target version | Runtime-only version upgrade |

### Subsection: Configuration Changes

| File | Property/Setting | Current | Required Change | Reason |
|------|------------------|---------|-----------------|--------|
| pom.xml | java.version | 17 | 25 | Required by project upgrade target |
| pom.xml | spring-boot-starter-parent | 3.3.4 | 3.5.x if compatibility issues arise | Required if Boot 3.3 does not compile cleanly on Java 25 |

### Subsection: CI/CD Changes

| File | Location | Current | Required Change |
|------|----------|---------|----------------|
| None identified | project root | no CI config discovered in the repo snapshot | no change required for the current workspace |

### Subsection: Risks & Warnings

- **No local Maven installation**: The project is Maven-based but no Maven binary was detected, so the first step must install a compatible Maven version before any verification can run. **Mitigation**: Install Maven 3.9+ and validate `mvn -v` before build commands.
- **No Java 17 runtime present**: The base project JDK is absent, so a baseline compile/test run cannot be executed on the original runtime. **Mitigation**: Skip baseline execution and rely on compile/test verification after the Java 25 toolchain is installed.
- **Java 25 compatibility with Boot 3.3.x**: Although the project is already on Spring Boot 3.3, the Java 25 target may require a newer managed Spring Boot line. **Mitigation**: If build or test compilation fails under Java 25, update the Boot parent to the nearest compatible 3.5.x release and re-run verification.

## Upgrade Steps

- Step 1: Install required Java and Maven toolchain
  - **Rationale**: The project has no Maven install and no Java 25 toolchain, so the environment must be prepared before build validation can run.
  - **Changes to Make**: Install JDK 25 and Maven 3.9+; validate both in the shell.
  - **Verification**: `java -version` and `mvn -v` from the project shell; Expected Result: Java 25 and Maven 3.9+ are available.

- Step 2: Setup Baseline
  - **Rationale**: This step confirms whether a baseline run is possible with the project’s current JDK. The current runtime is Java 17 in the project metadata, but the host does not have JDK 17 installed.
  - **Changes to Make**: Skip execution if the base JDK is unavailable; record the skip in the progress log.
  - **Verification**: No build command executed; Expected Result: Baseline is skipped due to missing Java 17 runtime.

- Step 3: Update Java target and compatibility metadata
  - **Rationale**: This is the actual runtime upgrade for the project. It updates the build metadata to Java 25 and applies the minimal compatibility fixes required by the JDK target.
  - **Changes to Make**: Apply all Dependency Changes and Configuration Changes from Impact Analysis; if Boot 3.3.x proves incompatible with the Java 25 toolchain, bump the parent to 3.5.x.
  - **Verification**: `mvn clean test-compile -q` under JDK 25; Expected Result: Main and test sources compile successfully.

- Step 4: CVE Validation & Fix
  - **Rationale**: Ensure the direct dependency set remains secure after the toolchain update and any compatibility bump.
  - **Changes to Make**: Run dependency listing and CVE validation; apply minimal patch-level dependency upgrades only if vulnerabilities are reported.
  - **Verification**: `mvn dependency:list -DexcludeTransitive=true` followed by the Java CVE validation tool; Expected Result: no unresolved direct dependency CVEs remain.

- Step 5: Final Validation
  - **Rationale**: This is the end-to-end proof that the Java 25 upgrade succeeded without regressions.
  - **Changes to Make**: Resolve any compile/test failures and keep the codebase in a stable state.
  - **Verification**: `mvn clean test -q` under JDK 25; Expected Result: 100% test pass rate and successful application build.
