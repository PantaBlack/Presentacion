# 🌍 Viva Idiomas — Centro de Idiomas

Sistema web educativo completo para el centro de idiomas **Viva Idiomas**, desarrollado en **Java Spring Boot MVC** con un diseño moderno azul marino/naranja, fiel a la identidad de marca.

La plataforma ofrece tres portales independientes (Administrador, Profesor y Alumno) además de un portal de Practicante, gestión de horarios, propuestas, materiales educativos e inscripciones a clases, con soporte multiidioma (Español / Francés / Inglés) y CAPTCHA matemático visual.

---

## ✨ Características principales

- **Landing page pública** con hero, banner promocional con cuenta regresiva, sección "¿Cómo funciona?", idiomas ofrecidos, características, planes/precios, estadísticas animadas y testimonios.
- **Autenticación segura** con Spring Security + BCrypt, CAPTCHA matemático visual (Canvas HTML5) y bloqueo temporal de cuenta tras varios intentos fallidos.
- **Auto-registro restringido**: solo con correo `@gmail.com` y solo como Alumno o Profesor. Los roles Practicante y Administrador los asigna un administrador desde `/admin/users`; nunca se obtienen registrándose.
- **Portal Administrador**: panel con estadísticas globales, gestión de propuestas (aprobar/rechazar con comentario), horarios de todos los profesores, materiales y gestión de usuarios/roles (incluye habilitar/deshabilitar cuentas).
- **Portal Profesor**: panel personal, gestión de horarios semanal, creación de propuestas y subida de materiales.
- **Portal Alumno**: panel, exploración e inscripción a clases por idioma, materiales y edición de perfil.
- **Portal Practicante**: panel propio para seguimiento de actividades y horas.
- **Multiidioma (i18n)**: Español (por defecto), Francés e Inglés, conmutables desde la barra superior.
- **Base de datos H2 embebida**: no requiere instalación, funciona de inmediato.

---

## 🧩 Requisitos

- **Java JDK 17** o superior
- **Maven 3.8+** (o usar el wrapper del IDE)

Verifica tu versión de Java:
```bash
java -version
```

---

## 🚀 Cómo ejecutar

### Opción A — Desde la línea de comandos (Maven)
```bash
cd viva-idiomas
mvn spring-boot:run
```
Luego abre en el navegador: **http://localhost:8080**

### Opción B — Empaquetar y ejecutar el JAR
```bash
mvn clean package
java -jar target/imfundo-kahle.jar
```

---

## 💻 Cómo abrir el proyecto en un IDE

### Eclipse
1. `File` → `Import...`
2. `Maven` → `Existing Maven Projects`
3. Selecciona la carpeta del proyecto (donde está el `pom.xml`)
4. `Finish` y espera a que Maven descargue las dependencias
5. Clic derecho en `ImfundoKahleApplication.java` → `Run As` → `Java Application`

### NetBeans
1. `File` → `Open Project`
2. Selecciona la carpeta del proyecto
3. Clic derecho en el proyecto → `Run`

### IntelliJ IDEA
1. `File` → `Open`
2. Selecciona el archivo `pom.xml` del proyecto → `Open as Project`
3. Espera la sincronización de Maven
4. Ejecuta la clase `ImfundoKahleApplication` con el botón ▶ Run

---

## 🔑 Credenciales de ejemplo

La aplicación crea datos de ejemplo al arrancar (usuarios, horarios, propuestas y materiales).
Ninguna credencial queda fija en el código: se leen de `application.properties`, que a su vez
las toma de variables de entorno. Estos son los valores por defecto para desarrollo local:

| Rol           | Correo                          | Contraseña             |
|---------------|----------------------------------|-------------------------|
| Administrador | admin@viva-idiomas.local         | `CambiaEsteAdmin#2026`  |
| Profesor      | maria.gonzalez@imfundo.org       | `CambiaEsta#2026`       |
| Profesor      | jean.dupont@imfundo.org          | `CambiaEsta#2026`       |
| Alumno        | lucia.ramirez@imfundo.org        | `CambiaEsta#2026`       |
| Alumno        | carlos.torres@imfundo.org        | `CambiaEsta#2026`       |
| Practicante   | alvaro.roca@imfundo.org          | `CambiaEsta#2026`       |

> ⚠️ Antes de desplegar en cualquier servidor accesible por otras personas, define
> `ADMIN_PASSWORD` y `SEED_PASSWORD` con contraseñas propias (o `SEED_DEMO_USERS=false`
> para no crear las ~68 cuentas de ejemplo). Ver la sección **Seguridad** más abajo.
>
> Los correos de ejemplo conservan el dominio `imfundo.org` del set de datos original;
> son solo datos de prueba y no afectan la marca ni el funcionamiento del sitio.

---

## 🔒 Seguridad

Este proyecto aplica varias capas de defensa, pensadas específicamente para que **no
baste con escribir una URL para entrar donde no se debe**:

- **Consola H2 apagada por defecto.** Antes estaba accesible en `/h2-console` sin
  ningún control propio: cualquiera podía ejecutar SQL arbitrario (por ejemplo,
  `UPDATE users SET role='ADMIN'...`) y auto-otorgarse el rol de administrador sin
  pasar por ningún login. Esa combinación era la causa real de poder "entrar poniendo
  la URL del admin". Para activarla solo en tu máquina, usa el perfil `dev`:
  ```bash
  mvn spring-boot:run -Dspring-boot.run.profiles=dev
  ```
  Disponible entonces en **http://localhost:8080/h2-console** (JDBC URL `jdbc:h2:mem:imfundodb`,
  usuario `sa`, contraseña vacía). **Nunca actives este perfil en un servidor público.**
- **Auto-registro controlado**: solo `@gmail.com`, solo rol Alumno o Profesor. Los roles
  Practicante y Administrador solo los asigna un administrador ya autenticado.
- **Bloqueo por fuerza bruta**: 5 intentos fallidos bloquean la cuenta 15 minutos.
- **CSRF activo en toda la aplicación**, incluida la API de actividades (antes exenta).
- **Un usuario autenticado que visita una sección de otro rol** es redirigido a su
  propio panel en vez de ver un error técnico que revele la estructura del sitio.
- **Máximo una sesión activa por cuenta**: iniciar sesión en un dispositivo nuevo
  cierra la sesión anterior.
- **Cuentas deshabilitables** desde `/admin/users`, sin necesidad de borrar el usuario.
- La base de datos H2 es **en memoria**: los datos se reinician cada vez que se detiene
  la aplicación.

---

## 🧱 Estructura del proyecto

```
viva-idiomas/
├── pom.xml
├── README.md
└── src/main/
    ├── java/com/imfundokahle/
    │   ├── ImfundoKahleApplication.java   # Clase principal
    │   ├── config/                        # Seguridad, i18n, datos iniciales
    │   ├── controller/                    # Controladores MVC
    │   ├── dto/                           # Formularios (RegisterForm)
    │   ├── model/                         # Entidades JPA y enums
    │   ├── repository/                    # Repositorios Spring Data JPA
    │   ├── security/                      # Filtro CAPTCHA
    │   ├── service/                       # Lógica de negocio
    │   └── validation/                    # Validaciones a medida (p. ej. @GmailAddress)
    └── resources/
        ├── application.properties
        ├── messages*.properties           # Textos ES / FR / EN
        ├── static/css/style.css           # Estilos azul marino / naranja
        ├── static/js/captcha.js           # CAPTCHA Canvas HTML5
        └── templates/                     # Vistas Thymeleaf
            ├── layout/fragments.html      # Marca, navbars, sidebars, mensajes flash
            └── index.html                 # Landing page pública "Viva Idiomas"
```

> El paquete Java (`com.imfundokahle`) y el nombre de la base de datos (`imfundodb`) conservan su nombre técnico original; renombrarlos no aporta valor al usuario final y arriesga romper referencias internas, por lo que el rebranding se aplicó a todo lo que la persona usuaria realmente ve: interfaz, textos, metadatos de la app y documentación.

---

## 🛠️ Tecnologías

- Spring Boot 3.3 · Spring MVC · Spring Security · Spring Data JPA
- Thymeleaf + Thymeleaf Security Extras
- Base de datos H2 (en memoria)
- HTML5 Canvas + JavaScript (CAPTCHA, contador animado, cuenta regresiva)
- CSS3 personalizado (sin frameworks pesados), tipografías Sora + Inter vía Google Fonts

---

## 📝 Notas

- El puerto por defecto es **8080**. Puedes cambiarlo en `src/main/resources/application.properties` (`server.port`).
- Todo el texto de la interfaz está internacionalizado; usa el selector **ES / FR / EN** de la barra superior.
- El CAPTCHA se valida en el servidor: la respuesta correcta se guarda en la sesión.
- Los precios mostrados en la sección "Precios" del landing son de ejemplo (`messages*.properties`, claves `pricing.*`); ajústalos a tus tarifas reales antes de publicar el sitio.

---

© 2026 Viva Idiomas — Empoderando a mujeres y niños a través de la educación en idiomas.
