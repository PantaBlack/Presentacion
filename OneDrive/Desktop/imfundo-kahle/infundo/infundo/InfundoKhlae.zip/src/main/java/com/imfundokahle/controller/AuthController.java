package com.imfundokahle.controller;

import com.imfundokahle.dto.RegisterForm;
import com.imfundokahle.model.Role;
import com.imfundokahle.model.User;
import com.imfundokahle.service.CaptchaService;
import com.imfundokahle.service.UserService;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

/**
 * Controlador de autenticacion: login, registro, CAPTCHA.
 * El procesamiento del login (POST) lo maneja Spring Security.
 */
@Controller
@RequestMapping("/auth")
public class AuthController {

    private final UserService userService;
    private final CaptchaService captchaService;

    public AuthController(UserService userService, CaptchaService captchaService) {
        this.userService = userService;
        this.captchaService = captchaService;
    }

    /** Muestra el formulario de inicio de sesion con un CAPTCHA nuevo. */
    @GetMapping("/login")
    public String loginPage(Model model) {
        model.addAttribute("captcha", captchaService.generate());
        return "auth/login";
    }

    /** Muestra el formulario de registro. */
    @GetMapping("/register")
    public String registerPage(Model model) {
        if (!model.containsAttribute("registerForm")) {
            model.addAttribute("registerForm", new RegisterForm());
        }
        model.addAttribute("captcha", captchaService.generate());
        return "auth/register";
    }

    /** Procesa el registro de un nuevo usuario. */
    @PostMapping("/register")
    public String register(@Valid @ModelAttribute("registerForm") RegisterForm form,
                           BindingResult result,
                           Model model,
                           RedirectAttributes redirectAttributes) {

        // Normalizar el correo (evita duplicados por diferencias de mayusculas)
        if (form.getEmail() != null) {
            form.setEmail(form.getEmail().trim().toLowerCase());
        }

        // Validar CAPTCHA (token firmado que viajo con el propio formulario, sin sesion)
        if (!captchaService.validate(form.getCaptchaAnswer(), form.getCaptchaToken())) {
            result.rejectValue("captchaAnswer", "captcha.error", "CAPTCHA incorrecto");
        }
        // Validar coincidencia de contrasenas
        if (form.getPassword() != null && !form.getPassword().equals(form.getConfirmPassword())) {
            result.rejectValue("confirmPassword", "password.mismatch", "Las contrasenas no coinciden");
        }
        // Validar email unico
        if (form.getEmail() != null && userService.emailExists(form.getEmail())) {
            result.rejectValue("email", "email.exists", "El correo ya esta registrado");
        }

        if (result.hasErrors()) {
            model.addAttribute("captcha", captchaService.generate());
            return "auth/register";
        }

        // Crear usuario. El DTO ya garantiza (via @Pattern) que el rol es STUDENT o TEACHER;
        // UserService.register() rechaza explicitamente cualquier otro rol como defensa en profundidad.
        User user = new User();
        user.setFirstName(form.getFirstName().trim());
        user.setLastName(form.getLastName().trim());
        user.setEmail(form.getEmail());
        user.setPassword(form.getPassword());

        Role selectedRole = Role.valueOf(form.getRole());
        userService.register(user, selectedRole);

        redirectAttributes.addFlashAttribute("successKey", "registro.exito");
        return "redirect:/auth/login";
    }

    /**
     * Endpoint AJAX para regenerar el CAPTCHA (boton "Regenerar").
     * Devuelve los operandos, el operador y el nuevo token firmado en JSON.
     */
    @GetMapping("/captcha")
    @ResponseBody
    public CaptchaService.CaptchaQuestion regenerateCaptcha() {
        return captchaService.generate();
    }
}
