package com.imfundokahle.service;

import org.springframework.stereotype.Service;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.time.Instant;
import java.util.Base64;
import java.util.Random;

/**
 * Servicio de CAPTCHA matematico, SIN ESTADO en el servidor.
 * <p>
 * La respuesta correcta nunca se guarda en la sesion HTTP: en su lugar viaja
 * firmada (HMAC-SHA256) dentro del propio formulario, en un campo oculto
 * "captchaToken". Esto evita el bug clasico de los captchas basados en sesion:
 * si la pagina se genera dos veces (dos pestanas, una recarga de fondo, un
 * reinicio de DevTools entre que se ve el captcha y se envia el formulario),
 * la segunda generacion sobreescribe la respuesta guardada de la primera y el
 * usuario recibe "captcha incorrecto" aunque haya escrito bien el resultado.
 * Al firmar el token junto a la pregunta, cada captcha se valida por si mismo
 * sin depender de que la sesion siga teniendo el mismo valor que cuando se
 * genero la pregunta.
 */
@Service
public class CaptchaService {

    /** Tiempo maximo que un captcha sigue siendo valido tras generarse. */
    private static final long EXPIRY_SECONDS = 10 * 60;

    private final Random random = new SecureRandom();
    private final Mac hmac;

    public CaptchaService() {
        try {
            byte[] key = new byte[32];
            new SecureRandom().nextBytes(key);
            hmac = Mac.getInstance("HmacSHA256");
            hmac.init(new SecretKeySpec(key, "HmacSHA256"));
        } catch (Exception e) {
            throw new IllegalStateException("No se pudo inicializar el firmado del CAPTCHA", e);
        }
    }

    /** Representa la pregunta CAPTCHA enviada a la vista, con su token firmado. */
    public static class CaptchaQuestion {
        public int num1;
        public int num2;
        public String operator;
        public String token;

        public CaptchaQuestion(int num1, int num2, String operator, String token) {
            this.num1 = num1;
            this.num2 = num2;
            this.operator = operator;
            this.token = token;
        }

        public int getNum1() { return num1; }
        public int getNum2() { return num2; }
        public String getOperator() { return operator; }
        public String getToken() { return token; }
    }

    /** Genera una nueva pregunta y su token firmado (no toca la sesion). */
    public CaptchaQuestion generate() {
        boolean isSum = random.nextBoolean();
        int a = random.nextInt(9) + 1;   // 1..9
        int b = random.nextInt(9) + 1;   // 1..9
        int answer;
        String operator;
        if (isSum) {
            operator = "+";
            answer = a + b;
        } else {
            // Asegurar resultado >= 0
            if (b > a) {
                int tmp = a; a = b; b = tmp;
            }
            operator = "-";
            answer = a - b;
        }
        String token = sign(answer);
        System.out.println("[CAPTCHA] Generado: " + a + " " + operator + " " + b + " = " + answer + " | token=" + token);
        return new CaptchaQuestion(a, b, operator, token);
    }

    /** Firma la respuesta correcta junto a una fecha de expiracion. */
    private synchronized String sign(int answer) {
        long expiry = Instant.now().getEpochSecond() + EXPIRY_SECONDS;
        String payload = answer + ":" + expiry;
        String payloadB64 = base64(payload.getBytes(StandardCharsets.UTF_8));
        String signature = base64(hmac.doFinal(payloadB64.getBytes(StandardCharsets.UTF_8)));
        return payloadB64 + "." + signature;
    }

    /**
     * Valida la respuesta del usuario contra el token firmado que viajo con el formulario.
     * No depende de ningun estado guardado previamente en el servidor.
     */
    public boolean validate(String userAnswer, String token) {
        System.out.println("[CAPTCHA] Validando -> userAnswer=" + userAnswer + " | token=" + token);

        if (userAnswer == null || token == null) {
            System.out.println("[CAPTCHA] FALLA: userAnswer o token es null");
            return false;
        }
        int dot = token.indexOf('.');
        if (dot < 0) {
            System.out.println("[CAPTCHA] FALLA: token no tiene formato payload.firma (no se encontro el punto)");
            return false;
        }
        String payloadB64 = token.substring(0, dot);
        String providedSignature = token.substring(dot + 1);

        String expectedSignature;
        synchronized (this) {
            expectedSignature = base64(hmac.doFinal(payloadB64.getBytes(StandardCharsets.UTF_8)));
        }
        System.out.println("[CAPTCHA] firma esperada=" + expectedSignature + " | firma recibida=" + providedSignature);
        if (!constantTimeEquals(expectedSignature, providedSignature)) {
            System.out.println("[CAPTCHA] FALLA: las firmas NO coinciden (token alterado o de otro servidor/instancia)");
            return false;
        }

        try {
            String payload = new String(Base64.getUrlDecoder().decode(payloadB64), StandardCharsets.UTF_8);
            int sep = payload.indexOf(':');
            int storedAnswer = Integer.parseInt(payload.substring(0, sep));
            long expiry = Long.parseLong(payload.substring(sep + 1));

            System.out.println("[CAPTCHA] storedAnswer=" + storedAnswer + " | expiry=" + expiry + " | ahora=" + Instant.now().getEpochSecond());

            if (Instant.now().getEpochSecond() > expiry) {
                System.out.println("[CAPTCHA] FALLA: el captcha ya vencio");
                return false;
            }
            boolean result = Integer.parseInt(userAnswer.trim()) == storedAnswer;
            System.out.println("[CAPTCHA] Comparacion final: userAnswer(trim)=" + userAnswer.trim()
                    + " vs storedAnswer=" + storedAnswer + " -> resultado=" + result);
            return result;
        } catch (RuntimeException e) {
            System.out.println("[CAPTCHA] FALLA: excepcion al parsear el payload -> " + e);
            return false;
        }
    }

    private static String base64(byte[] bytes) {
        return Base64.getUrlEncoder().withoutPadding().encodeToString(bytes);
    }

    /** Comparacion en tiempo constante para no filtrar informacion por temporizacion. */
    private static boolean constantTimeEquals(String a, String b) {
        return MessageDigest.isEqual(
                a.getBytes(StandardCharsets.UTF_8),
                b.getBytes(StandardCharsets.UTF_8));
    }
}