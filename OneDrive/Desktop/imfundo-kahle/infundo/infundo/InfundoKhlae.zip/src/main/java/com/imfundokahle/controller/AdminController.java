package com.imfundokahle.controller;

import com.imfundokahle.model.*;
import com.imfundokahle.service.*;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;
import java.util.stream.Collectors;

/**
 * Controlador del portal de administrador (/admin/**).
 */
@Controller
@RequestMapping("/admin")
public class AdminController {

    private final UserService userService;
    private final ScheduleService scheduleService;
    private final ProposalService proposalService;
    private final MaterialService materialService;

    public AdminController(UserService userService, ScheduleService scheduleService,
                          ProposalService proposalService, MaterialService materialService) {
        this.userService = userService;
        this.scheduleService = scheduleService;
        this.proposalService = proposalService;
        this.materialService = materialService;
    }

    /** Dashboard con estadisticas globales. */
    @GetMapping({"", "/", "/dashboard"})
    public String dashboard(Model model) {
        model.addAttribute("totalTeachers", userService.countByRole(Role.TEACHER));
        model.addAttribute("totalStudents", userService.countByRole(Role.STUDENT));
        model.addAttribute("totalPracticantes", userService.countByRole(Role.PRACTICANTE));
        model.addAttribute("totalAdmins", userService.countByRole(Role.ADMIN));
        model.addAttribute("totalUsers", userService.countAll());
        model.addAttribute("pendingProposals", proposalService.countByStatus(ProposalStatus.PENDING));
        model.addAttribute("approvedProposals", proposalService.countByStatus(ProposalStatus.APPROVED));
        model.addAttribute("rejectedProposals", proposalService.countByStatus(ProposalStatus.REJECTED));
        model.addAttribute("totalMaterials", materialService.countAll());
        model.addAttribute("totalSchedules", scheduleService.countActiveSchedules());
        model.addAttribute("recentProposals", proposalService.findRecentPending());
        model.addAttribute("recentUsers", userService.findRecentUsers());

        // Ocupacion global: plazas ocupadas frente a plazas ofertadas
        List<Schedule> allSchedules = scheduleService.findAll();
        long seatsTotal = 0;
        long seatsTaken = 0;
        for (Schedule s : allSchedules) {
            seatsTotal += s.getMaxStudents();
            seatsTaken += scheduleService.countActiveEnrollments(s);
        }
        model.addAttribute("seatsTotal", seatsTotal);
        model.addAttribute("seatsTaken", seatsTaken);
        model.addAttribute("upcomingSchedules",
                allSchedules.stream().limit(5).collect(Collectors.toList()));
        model.addAttribute("scheduleService", scheduleService);
        return "admin/dashboard";
    }

    /** Gestion de propuestas con filtros. */
    @GetMapping("/proposals")
    public String proposals(@RequestParam(required = false) String status,
                            @RequestParam(required = false) String type,
                            Model model) {
        List<Proposal> proposals = proposalService.findAll();
        if (status != null && !status.isEmpty()) {
            ProposalStatus st = ProposalStatus.valueOf(status);
            proposals = proposals.stream().filter(p -> p.getStatus() == st).collect(Collectors.toList());
        }
        if (type != null && !type.isEmpty()) {
            ProposalType tp = ProposalType.valueOf(type);
            proposals = proposals.stream().filter(p -> p.getType() == tp).collect(Collectors.toList());
        }
        model.addAttribute("proposals", proposals);
        model.addAttribute("statusFilter", status);
        model.addAttribute("typeFilter", type);
        model.addAttribute("statuses", ProposalStatus.values());
        model.addAttribute("types", ProposalType.values());
        return "admin/proposals";
    }

    /** Aprobar o rechazar una propuesta. */
    @PostMapping("/proposals/{id}/review")
    public String reviewProposal(@PathVariable Long id,
                                 @RequestParam String decision,
                                 @RequestParam(required = false) String adminComment,
                                 RedirectAttributes ra) {
        if (adminComment == null || adminComment.trim().isEmpty()) {
            ra.addFlashAttribute("errorKey", "proposal.comment.required");
            return "redirect:/admin/proposals";
        }
        ProposalStatus newStatus = "APPROVE".equalsIgnoreCase(decision)
                ? ProposalStatus.APPROVED : ProposalStatus.REJECTED;
        proposalService.review(id, newStatus, adminComment);
        ra.addFlashAttribute("successKey", "proposal.reviewed");
        return "redirect:/admin/proposals";
    }

    /** Vista de todos los horarios con filtros. */
    @GetMapping("/schedules")
    public String schedules(@RequestParam(required = false) Long teacherId,
                            @RequestParam(required = false) String language,
                            Model model) {
        List<Schedule> schedules = scheduleService.findAll();
        if (teacherId != null) {
            schedules = schedules.stream()
                    .filter(s -> s.getTeacher().getId().equals(teacherId))
                    .collect(Collectors.toList());
        }
        if (language != null && !language.isEmpty()) {
            Language lang = Language.valueOf(language);
            schedules = schedules.stream().filter(s -> s.getLanguage() == lang).collect(Collectors.toList());
        }
        // Anexar conteo de inscritos
        model.addAttribute("schedules", schedules);
        model.addAttribute("scheduleService", scheduleService);
        model.addAttribute("teachers", userService.findByRole(Role.TEACHER));
        model.addAttribute("languages", Language.values());
        model.addAttribute("teacherFilter", teacherId);
        model.addAttribute("languageFilter", language);
        return "admin/schedules";
    }

    /** Gestion de materiales con filtros. */
    @GetMapping("/materials")
    public String materials(@RequestParam(required = false) Long teacherId,
                            @RequestParam(required = false) String category,
                            @RequestParam(required = false) String language,
                            Model model) {
        List<Material> materials = materialService.findAll();
        if (teacherId != null) {
            materials = materials.stream()
                    .filter(m -> m.getTeacher().getId().equals(teacherId))
                    .collect(Collectors.toList());
        }
        if (category != null && !category.isEmpty()) {
            MaterialCategory cat = MaterialCategory.valueOf(category);
            materials = materials.stream().filter(m -> m.getCategory() == cat).collect(Collectors.toList());
        }
        if (language != null && !language.isEmpty()) {
            Language lang = Language.valueOf(language);
            materials = materials.stream().filter(m -> m.getLanguage() == lang).collect(Collectors.toList());
        }
        model.addAttribute("materials", materials);
        model.addAttribute("teachers", userService.findByRole(Role.TEACHER));
        model.addAttribute("categories", MaterialCategory.values());
        model.addAttribute("languages", Language.values());
        model.addAttribute("teacherFilter", teacherId);
        model.addAttribute("categoryFilter", category);
        model.addAttribute("languageFilter", language);
        return "admin/materials";
    }

    /** Eliminar material inapropiado. */
    @PostMapping("/materials/{id}/delete")
    public String deleteMaterial(@PathVariable Long id, RedirectAttributes ra) {
        materialService.delete(id);
        ra.addFlashAttribute("successKey", "material.deleted");
        return "redirect:/admin/materials";
    }

    /** Gestion de usuarios. */
    @GetMapping("/users")
    public String users(Model model) {
        model.addAttribute("users", userService.findAll());
        model.addAttribute("roles", Role.values());
        return "admin/users";
    }

    /** Cambiar el rol de un usuario. */
    @PostMapping("/users/{id}/role")
    public String changeRole(@PathVariable Long id, @RequestParam String role, RedirectAttributes ra) {
        userService.updateRole(id, Role.valueOf(role));
        ra.addFlashAttribute("successKey", "user.role.updated");
        return "redirect:/admin/users";
    }

    /** Habilitar o deshabilitar una cuenta: forma directa de cortar el acceso de alguien. */
    @PostMapping("/users/{id}/toggle-enabled")
    public String toggleEnabled(@PathVariable Long id, @RequestParam boolean enabled,
                                java.security.Principal principal, RedirectAttributes ra) {
        User target = userService.findById(id).orElse(null);
        if (target != null && !enabled && target.getEmail().equalsIgnoreCase(principal.getName())) {
            // Evita que un administrador se bloquee a si mismo por accidente.
            ra.addFlashAttribute("errorKey", "user.disable.self.forbidden");
            return "redirect:/admin/users";
        }
        userService.setEnabled(id, enabled);
        ra.addFlashAttribute("successKey", enabled ? "user.enabled.updated" : "user.disabled.updated");
        return "redirect:/admin/users";
    }
}
