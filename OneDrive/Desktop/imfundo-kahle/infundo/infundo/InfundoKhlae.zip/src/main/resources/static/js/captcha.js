/* ============================================================
   CAPTCHA matematico visual con Canvas HTML5
   - Dibuja la operacion recibida del servidor con ruido grafico
   - Numeros con rotacion y colores variados
   - Boton "Regenerar" que pide una nueva operacion al servidor
   ============================================================ */

(function () {
    const canvas = document.getElementById('captchaCanvas');
    if (!canvas) return;
    const ctx = canvas.getContext('2d');

    // Operacion inicial inyectada por el servidor (data-attributes)
    let num1 = parseInt(canvas.dataset.num1, 10);
    let num2 = parseInt(canvas.dataset.num2, 10);
    let operator = canvas.dataset.operator;

    function randomColor() {
        const colors = ['#1E3A6E', '#F15A24', '#14294F', '#D14A15', '#00875a', '#4f46e5'];
        return colors[Math.floor(Math.random() * colors.length)];
    }

    function drawNoise() {
        // Puntos aleatorios (menos densos que antes: no deben tapar los numeros)
        for (let i = 0; i < 55; i++) {
            ctx.fillStyle = 'rgba(30,58,110,' + (Math.random() * 0.22) + ')';
            ctx.fillRect(Math.random() * canvas.width, Math.random() * canvas.height, 2, 2);
        }
        // Lineas aleatorias, suaves
        for (let i = 0; i < 3; i++) {
            ctx.strokeStyle = 'rgba(241,90,36,' + (Math.random() * 0.3) + ')';
            ctx.beginPath();
            ctx.moveTo(Math.random() * canvas.width, Math.random() * canvas.height);
            ctx.lineTo(Math.random() * canvas.width, Math.random() * canvas.height);
            ctx.stroke();
        }
    }

    function drawChar(char, x) {
        ctx.save();
        const y = 38 + (Math.random() * 4 - 2);
        ctx.translate(x, y);
        // Rotacion leve: legible pero sigue siendo dificil de leer para un bot simple
        const angle = (Math.random() * 14 - 7) * Math.PI / 180;
        ctx.rotate(angle);
        ctx.font = 'bold 30px "Segoe UI", Arial';
        ctx.fillStyle = randomColor();
        ctx.fillText(char, 0, 0);
        ctx.restore();
    }

    function render() {
        ctx.fillStyle = '#EAF1FB';
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        drawNoise();
        const text = num1 + ' ' + operator + ' ' + num2 + ' =';
        let x = 18;
        for (const ch of text) {
            drawChar(ch, x);
            x += 22;
        }
        drawNoise();
    }

    // Regenerar: pedir nueva operacion (y su token firmado) al servidor.
    // Es imprescindible actualizar tambien el campo oculto captchaToken: si se
    // deja el token viejo, el servidor rechazara la respuesta aunque este bien
    // calculada, porque ya no corresponde a los numeros que se ven en pantalla.
    async function regenerate() {
        try {
            const resp = await fetch('/auth/captcha', { headers: { 'Accept': 'application/json' } });
            const data = await resp.json();
            num1 = data.num1;
            num2 = data.num2;
            operator = data.operator;
            render();
            const input = document.getElementById('captchaAnswer');
            if (input) input.value = '';
            const tokenInput = document.getElementById('captchaToken');
            if (tokenInput) tokenInput.value = data.token;
        } catch (e) {
            console.error('Error al regenerar el CAPTCHA', e);
        }
    }

    const reloadBtn = document.getElementById('captchaReload');
    if (reloadBtn) reloadBtn.addEventListener('click', regenerate);

    render();
})();