package com.imfundokahle.controller;

import com.imfundokahle.model.Role;
import com.imfundokahle.model.User;
import com.imfundokahle.service.ActividadService;
import com.imfundokahle.service.UserService;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ModelAttribute;

import java.security.Principal;
import java.util.EnumSet;
import java.util.Set;

/**
 * Advice global que expone datos comunes a todas las vistas: el usuario
 * autenticado (para navbar, avatar, saludo) y, para profesores, alumnos y
 * practicantes, cuantas actividades pendientes tiene asignadas el
 * administrador (para el aviso en la barra lateral).
 */
@ControllerAdvice
public class GlobalModelAdvice {

    private static final Set<Role> ROLES_CON_ACTIVIDADES =
            EnumSet.of(Role.TEACHER, Role.STUDENT, Role.PRACTICANTE);

    private final UserService userService;
    private final ActividadService actividadService;

    public GlobalModelAdvice(UserService userService, ActividadService actividadService) {
        this.userService = userService;
        this.actividadService = actividadService;
    }

    @ModelAttribute("currentUser")
    public User currentUser(Principal principal) {
        if (principal == null) {
            return null;
        }
        return userService.findByEmail(principal.getName()).orElse(null);
    }

    /** Actividades pendientes de revisar: alimenta el aviso en la barra lateral. */
    @ModelAttribute("pendingActivitiesCount")
    public long pendingActivitiesCount(Principal principal) {
        if (principal == null) {
            return 0;
        }
        User user = userService.findByEmail(principal.getName()).orElse(null);
        if (user == null || !ROLES_CON_ACTIVIDADES.contains(user.getRole())) {
            return 0;
        }
        return actividadService.obtenerResumenPara(user.getFullName()).pendientes();
    }
}
