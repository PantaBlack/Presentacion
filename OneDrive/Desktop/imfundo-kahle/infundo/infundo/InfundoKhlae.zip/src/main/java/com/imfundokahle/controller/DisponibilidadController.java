package com.imfundokahle.controller;

import com.imfundokahle.model.Horario;
import com.imfundokahle.model.Role;
import com.imfundokahle.model.User;
import com.imfundokahle.repository.UserRepository;
import com.imfundokahle.service.HorarioService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.*;
import java.util.stream.Collectors;

@Controller
@RequestMapping("/admin")
public class DisponibilidadController {

    private final HorarioService horarioService;
    private final UserRepository userRepository;

    public DisponibilidadController(HorarioService horarioService, UserRepository userRepository) {
        this.horarioService = horarioService;
        this.userRepository = userRepository;
    }

    // 1. MUESTRA LA LISTA Y EL CRUCE POR DÍA
    @GetMapping("/disponibilidad")
    public String listaUsuarios(@RequestParam(required = false) String diaFiltro, Model model) {
        model.addAttribute("titulo", "Cruce de Disponibilidad");
        model.addAttribute("activeTab", "disponibilidad");

        List<User> todosLosUsuarios = userRepository.findAll().stream()
                .filter(u -> u.getRole() != Role.ADMIN)
                .collect(Collectors.toList());

        List<String> dias = Arrays.asList("LUNES", "MARTES", "MIERCOLES", "JUEVES", "VIERNES");
        model.addAttribute("dias", dias);
        model.addAttribute("diaFiltro", diaFiltro);

        // Si el administrador selecciona un día, agrupamos los horarios por hora
        if (diaFiltro != null && !diaFiltro.isEmpty()) {
            // TreeMap ordena automáticamente las horas (08:00, 09:00, etc.)
            Map<String, List<Horario>> crucePorHora = new TreeMap<>(); 
            
            for (User u : todosLosUsuarios) {
                // "Efectivo" incluye el almuerzo obligatorio de 13:00, aunque no este guardado.
                List<Horario> horariosUser = horarioService.obtenerHorarioEfectivo(u);
                for (Horario h : horariosUser) {
                    if (h.getDiaSemana().equalsIgnoreCase(diaFiltro)) {
                        crucePorHora.computeIfAbsent(h.getHoraInicio(), k -> new ArrayList<>()).add(h);
                    }
                }
            }
            model.addAttribute("crucePorHora", crucePorHora);
        }

        model.addAttribute("usuarios", todosLosUsuarios);
        return "admin/disponibilidad-list";
    }

    // 2. MUESTRA EL EXCEL DE UN USUARIO ESPECÍFICO (Se mantiene intacto)
    @GetMapping("/disponibilidad/inspeccionar/{id}")
    public String inspeccionarHorario(@PathVariable Long id, Model model) {
        User usuario = userRepository.findById(id).orElseThrow(() -> new RuntimeException("Usuario no encontrado"));
        
        model.addAttribute("titulo", "Horario de " + usuario.getFirstName());
        model.addAttribute("activeTab", "disponibilidad");
        model.addAttribute("usuario", usuario);

        List<String> horas = Arrays.asList("08:00", "09:00", "10:00", "11:00", "12:00", "13:00", "14:00", "15:00", "16:00", "17:00", "18:00", "19:00", "20:00");
        List<String> dias = Arrays.asList("LUNES", "MARTES", "MIERCOLES", "JUEVES", "VIERNES");

        // "Efectivo" incluye el almuerzo obligatorio de 13:00, aunque no este guardado.
        List<Horario> horarios = horarioService.obtenerHorarioEfectivo(usuario);
        Map<String, Map<String, String>> mapaHoras = new LinkedHashMap<>();
        
        for (String hora : horas) {
            Map<String, String> mapaDias = new LinkedHashMap<>();
            for (String dia : dias) {
                String modalidad = horarios.stream()
                        .filter(h -> h.getDiaSemana().equals(dia) && h.getHoraInicio().startsWith(hora))
                        .map(Horario::getModalidad)
                        .findFirst().orElse("");
                mapaDias.put(dia, modalidad);
            }
            mapaHoras.put(hora, mapaDias);
        }

        model.addAttribute("mapaHoras", mapaHoras);
        model.addAttribute("horas", horas);
        model.addAttribute("dias", dias);

        return "admin/disponibilidad-detalle";
    }
}