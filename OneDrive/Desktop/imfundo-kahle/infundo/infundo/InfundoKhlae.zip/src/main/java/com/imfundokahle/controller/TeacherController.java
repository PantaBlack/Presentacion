package com.imfundokahle.controller;

import com.imfundokahle.model.*;
import com.imfundokahle.service.*;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MaxUploadSizeExceededException;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.io.IOException;
import java.security.Principal;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Controlador del portal de profesor (/teacher/**).
 */
@Controller
@RequestMapping("/teacher")
public class TeacherController {

    private final UserService userService;
    private final ScheduleService scheduleService;
    private final ProposalService proposalService;
    private final MaterialService materialService;
    private final ActividadService actividadService;

    public TeacherController(UserService userService, ScheduleService scheduleService,
                            ProposalService proposalService, MaterialService materialService,
                            ActividadService actividadService) {
        this.userService = userService;
        this.scheduleService = scheduleService;
        this.proposalService = proposalService;
        this.materialService = materialService;
        this.actividadService = actividadService;
    }

    /** Obtiene el profesor autenticado. */
    private User current(Principal principal) {
        return userService.findByEmail(principal.getName()).orElseThrow();
    }

    /** Dashboard personal del profesor. */
    @GetMapping({"", "/", "/dashboard"})
    public String dashboard(Principal principal, Model model) {
        User teacher = current(principal);
        model.addAttribute("mySchedules", scheduleService.countByTeacher(teacher));
        model.addAttribute("pendingProposals",
                proposalService.countByTeacherAndStatus(teacher, ProposalStatus.PENDING));
        model.addAttribute("myMaterials", materialService.countByTeacher(teacher));
        model.addAttribute("myStudents", scheduleService.countStudentsOfTeacher(teacher));

        List<Schedule> mine = scheduleService.findByTeacher(teacher);
        model.addAttribute("schedules", mine);
        model.addAttribute("recentProposals", proposalService.findByTeacher(teacher));
        model.addAttribute("approvedProposals",
                proposalService.countByTeacherAndStatus(teacher, ProposalStatus.APPROVED));
        model.addAttribute("rejectedProposals",
                proposalService.countByTeacherAndStatus(teacher, ProposalStatus.REJECTED));

        // Ocupacion de las clases del profesor (plazas ocupadas / ofertadas)
        long seatsTotal = 0;
        long seatsTaken = 0;
        for (Schedule s : mine) {
            seatsTotal += s.getMaxStudents();
            seatsTaken += scheduleService.countActiveEnrollments(s);
        }
        model.addAttribute("seatsTotal", seatsTotal);
        model.addAttribute("seatsTaken", seatsTaken);
        model.addAttribute("scheduleService", scheduleService);

        // Agenda semanal ya agrupada por dia (evita filtrar dentro de la vista)
        Map<DayOfWeekEnum, List<Schedule>> byDay = new LinkedHashMap<>();
        for (DayOfWeekEnum d : DayOfWeekEnum.values()) {
            byDay.put(d, new ArrayList<>());
        }
        for (Schedule s : mine) {
            if (s.getDayOfWeek() != null) {
                byDay.get(s.getDayOfWeek()).add(s);
            }
        }
        model.addAttribute("schedulesByDay", byDay);

        // Tareas que el administrador le haya asignado (panel de Actividades y Horas)
        model.addAttribute("misActividades", actividadService.obtenerResumenPara(teacher.getFullName()));

        return "teacher/dashboard";
    }

    /** Gestion de horarios: vista semanal. */
    @GetMapping("/schedules")
    public String schedules(Principal principal, Model model) {
        User teacher = current(principal);
        model.addAttribute("schedules", scheduleService.findByTeacher(teacher));
        model.addAttribute("scheduleService", scheduleService);
        model.addAttribute("days", DayOfWeekEnum.values());
        model.addAttribute("languages", Language.values());
        model.addAttribute("newSchedule", new Schedule());
        return "teacher/schedules";
    }

    /** Crear un nuevo horario. */
    @PostMapping("/schedules")
    public String createSchedule(Principal principal,
                                 @RequestParam String dayOfWeek,
                                 @RequestParam String startTime,
                                 @RequestParam String endTime,
                                 @RequestParam String subject,
                                 @RequestParam String language,
                                 @RequestParam(required = false) String description,
                                 @RequestParam(defaultValue = "10") int maxStudents,
                                 RedirectAttributes ra) {
        User teacher = current(principal);
        Schedule s = new Schedule();
        s.setTeacher(teacher);
        s.setDayOfWeek(DayOfWeekEnum.valueOf(dayOfWeek));
        s.setStartTime(LocalTime.parse(startTime));
        s.setEndTime(LocalTime.parse(endTime));
        s.setSubject(subject);
        s.setLanguage(Language.valueOf(language));
        s.setDescription(description);
        s.setMaxStudents(maxStudents);
        scheduleService.save(s);
        ra.addFlashAttribute("successKey", "schedule.created");
        return "redirect:/teacher/schedules";
    }

    /** Eliminar un horario propio. */
    @PostMapping("/schedules/{id}/delete")
    public String deleteSchedule(Principal principal, @PathVariable Long id, RedirectAttributes ra) {
        Schedule s = scheduleService.findById(id);
        if (s != null && s.getTeacher().getEmail().equals(principal.getName())) {
            scheduleService.delete(id);
            ra.addFlashAttribute("successKey", "schedule.deleted");
        }
        return "redirect:/teacher/schedules";
    }

    /** Ver alumnos inscritos en un horario. */
    @GetMapping("/schedules/{id}/students")
    public String scheduleStudents(Principal principal, @PathVariable Long id, Model model) {
        Schedule s = scheduleService.findById(id);
        if (s == null || !s.getTeacher().getEmail().equals(principal.getName())) {
            return "redirect:/teacher/schedules";
        }
        model.addAttribute("schedule", s);
        model.addAttribute("enrollments", scheduleService.findEnrollmentsBySchedule(s));
        return "teacher/schedule-students";
    }

    /** Lista y creacion de propuestas. */
    @GetMapping("/proposals")
    public String proposals(Principal principal, Model model) {
        User teacher = current(principal);
        model.addAttribute("proposals", proposalService.findByTeacher(teacher));
        model.addAttribute("types", ProposalType.values());
        return "teacher/proposals";
    }

    @PostMapping("/proposals")
    public String createProposal(Principal principal,
                                 @RequestParam String type,
                                 @RequestParam String title,
                                 @RequestParam String description,
                                 RedirectAttributes ra) {
        User teacher = current(principal);
        Proposal p = new Proposal();
        p.setTeacher(teacher);
        p.setType(ProposalType.valueOf(type));
        p.setTitle(title);
        p.setDescription(description);
        p.setStatus(ProposalStatus.PENDING);
        proposalService.save(p);
        ra.addFlashAttribute("successKey", "proposal.created");
        return "redirect:/teacher/proposals";
    }

    /** Gestion de materiales. */
    @GetMapping("/materials")
    public String materials(Principal principal, Model model) {
        User teacher = current(principal);
        model.addAttribute("materials", materialService.findByTeacher(teacher));
        model.addAttribute("categories", MaterialCategory.values());
        model.addAttribute("languages", Language.values());
        model.addAttribute("visibilities", MaterialVisibility.values());
        return "teacher/materials";
    }

    @PostMapping("/materials")
    public String createMaterial(Principal principal,
                                 @RequestParam String title,
                                 @RequestParam(required = false) String description,
                                 @RequestParam String category,
                                 @RequestParam String language,
                                 @RequestParam(required = false) String externalLink,
                                 @RequestParam(defaultValue = "EVERYONE") String visibility,
                                 @RequestParam(required = false) MultipartFile archivo,
                                 RedirectAttributes ra) {
        User teacher = current(principal);

        boolean hayArchivo = archivo != null && !archivo.isEmpty();
        boolean hayEnlace = externalLink != null && !externalLink.isBlank();
        if (!hayArchivo && !hayEnlace) {
            ra.addFlashAttribute("errorKey", "material.needsFileOrLink");
            return "redirect:/teacher/materials";
        }

        Material m = new Material();
        m.setTeacher(teacher);
        m.setTitle(title);
        m.setDescription(description);
        m.setCategory(MaterialCategory.valueOf(category));
        m.setLanguage(Language.valueOf(language));
        m.setExternalLink(hayEnlace ? externalLink : null);
        m.setVisibility(MaterialVisibility.valueOf(visibility));

        if (hayArchivo) {
            try {
                m.setFileName(archivo.getOriginalFilename());
                m.setFileType(archivo.getContentType());
                m.setFileSize(archivo.getSize());
                m.setFileData(archivo.getBytes());
            } catch (IOException e) {
                ra.addFlashAttribute("errorKey", "material.uploadError");
                return "redirect:/teacher/materials";
            }
        }

        materialService.save(m);
        ra.addFlashAttribute("successKey", "material.created");
        return "redirect:/teacher/materials";
    }

    /** El archivo supera el limite configurado (spring.servlet.multipart.max-file-size). */
    @ExceptionHandler(MaxUploadSizeExceededException.class)
    public String archivoDemasiadoGrande(RedirectAttributes ra) {
        ra.addFlashAttribute("errorKey", "material.fileTooLarge");
        return "redirect:/teacher/materials";
    }

    @PostMapping("/materials/{id}/delete")
    public String deleteMaterial(Principal principal, @PathVariable Long id, RedirectAttributes ra) {
        Material m = materialService.findById(id);
        if (m != null && m.getTeacher().getEmail().equals(principal.getName())) {
            materialService.delete(id);
            ra.addFlashAttribute("successKey", "material.deleted");
        }
        return "redirect:/teacher/materials";
    }
}
