package com.imfundokahle.service;

import com.imfundokahle.model.*;
import com.imfundokahle.repository.ClassEnrollmentRepository;
import com.imfundokahle.repository.ScheduleRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * Servicio de horarios e inscripciones.
 */
@Service
public class ScheduleService {

    private final ScheduleRepository scheduleRepository;
    private final ClassEnrollmentRepository enrollmentRepository;

    public ScheduleService(ScheduleRepository scheduleRepository,
                           ClassEnrollmentRepository enrollmentRepository) {
        this.scheduleRepository = scheduleRepository;
        this.enrollmentRepository = enrollmentRepository;
    }

    @Transactional
    public Schedule save(Schedule schedule) {
        return scheduleRepository.save(schedule);
    }

    public Schedule findById(Long id) {
        return scheduleRepository.findById(id).orElse(null);
    }

    public List<Schedule> findAll() {
        return scheduleRepository.findAllByOrderByDayOfWeekAscStartTimeAsc();
    }

    public List<Schedule> findByTeacher(User teacher) {
        return scheduleRepository.findByTeacherOrderByDayOfWeekAscStartTimeAsc(teacher);
    }

    public long countByTeacher(User teacher) {
        return scheduleRepository.countByTeacher(teacher);
    }

    @Transactional
    public void delete(Long id) {
        Schedule s = findById(id);
        if (s != null) {
            // Eliminar inscripciones asociadas antes de borrar el horario
            List<ClassEnrollment> enrollments = enrollmentRepository.findBySchedule(s);
            enrollmentRepository.deleteAll(enrollments);
            scheduleRepository.delete(s);
        }
    }

    // ---- Inscripciones ----

    /** Numero de alumnos activos en un horario. */
    public long countActiveEnrollments(Schedule schedule) {
        return enrollmentRepository.countByScheduleAndStatus(schedule, EnrollmentStatus.ACTIVE);
    }

    /** Plazas disponibles en un horario. */
    public long availableSeats(Schedule schedule) {
        return schedule.getMaxStudents() - countActiveEnrollments(schedule);
    }

    public boolean isStudentEnrolled(User student, Schedule schedule) {
        return enrollmentRepository.findByStudentAndSchedule(student, schedule)
                .filter(e -> e.getStatus() == EnrollmentStatus.ACTIVE)
                .isPresent();
    }

    /** Inscribe a un alumno en un horario si hay cupo y no esta ya inscrito. */
    @Transactional
    public String enroll(User student, Schedule schedule) {
        if (isStudentEnrolled(student, schedule)) {
            return "already";
        }
        if (availableSeats(schedule) <= 0) {
            return "full";
        }
        // Reutilizar inscripcion cancelada si existe
        ClassEnrollment enrollment = enrollmentRepository
                .findByStudentAndSchedule(student, schedule)
                .orElseGet(ClassEnrollment::new);
        enrollment.setStudent(student);
        enrollment.setSchedule(schedule);
        enrollment.setStatus(EnrollmentStatus.ACTIVE);
        if (enrollment.getEnrolledAt() == null) {
            enrollment.setEnrolledAt(java.time.LocalDateTime.now());
        }
        enrollmentRepository.save(enrollment);
        return "ok";
    }

    @Transactional
    public void cancelEnrollment(User student, Schedule schedule) {
        enrollmentRepository.findByStudentAndSchedule(student, schedule).ifPresent(e -> {
            e.setStatus(EnrollmentStatus.CANCELLED);
            enrollmentRepository.save(e);
        });
    }

    public List<ClassEnrollment> findEnrollmentsByStudent(User student) {
        return enrollmentRepository.findByStudentAndStatus(student, EnrollmentStatus.ACTIVE);
    }

    public List<ClassEnrollment> findEnrollmentsBySchedule(Schedule schedule) {
        return enrollmentRepository.findByScheduleAndStatus(schedule, EnrollmentStatus.ACTIVE);
    }

    public long countEnrollmentsByStudent(User student) {
        return enrollmentRepository.countByStudentAndStatus(student, EnrollmentStatus.ACTIVE);
    }

    /** Cuenta el total de alumnos inscritos en los horarios de un profesor. */
    public long countStudentsOfTeacher(User teacher) {
        long total = 0;
        for (Schedule s : findByTeacher(teacher)) {
            total += countActiveEnrollments(s);
        }
        return total;
    }

    public long countActiveSchedules() {
        return scheduleRepository.count();
    }
}
