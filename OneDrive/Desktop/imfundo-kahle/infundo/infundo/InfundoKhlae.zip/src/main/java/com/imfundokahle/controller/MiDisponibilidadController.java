package com.imfundokahle.controller;

import com.imfundokahle.model.Actividad;
import com.imfundokahle.model.User;
import com.imfundokahle.service.ActividadService;
import com.imfundokahle.service.HorarioService;
import com.imfundokahle.service.UserService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;
import java.time.LocalTime;
import java.time.format.DateTimeParseException;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Disponibilidad semanal propia: cada profesor, alumno o practicante marca
 * aqui en que horas puede atender y de que forma (presencial, virtual, o
 * su hora de almuerzo). Es la misma tabla que despues ve el administrador,
 * de forma consolidada, en /admin/disponibilidad.
 */
@Controller
@RequestMapping("/mi-disponibilidad")
public class MiDisponibilidadController {

    private final UserService userService;
    private final HorarioService horarioService;
    private final ActividadService actividadService;

    public MiDisponibilidadController(UserService userService, HorarioService horarioService,
                                      ActividadService actividadService) {
        this.userService = userService;
        this.horarioService = horarioService;
        this.actividadService = actividadService;
    }

    private User current(Principal principal) {
        return userService.findByEmail(principal.getName()).orElseThrow();
    }

    @GetMapping
    public String ver(Principal principal, Model model) {
        User user = current(principal);
        model.addAttribute("dias", HorarioService.DIAS_SEMANA);
        model.addAttribute("horas", HorarioService.HORAS_DEL_DIA);
        model.addAttribute("celdas", horarioService.obtenerMapaSemanal(user));
        model.addAttribute("activeRole", user.getRole().name());

        // Que celdas tienen una actividad asignada por el admin, para resaltarlas en la cuadricula.
        List<Actividad> misActividades = actividadService.obtenerResumenPara(user.getFullName()).actividades();
        model.addAttribute("actividadesPorCelda", mapaActividadesPorCelda(misActividades));

        return "shared/mi-disponibilidad";
    }

    /** Alterna el estado de una celda (AJAX): devuelve la modalidad que quedo guardada. */
    @PostMapping("/celda")
    @ResponseBody
    public Map<String, String> actualizarCelda(Principal principal,
                                               @RequestParam String dia,
                                               @RequestParam String horaInicio,
                                               @RequestParam String modalidad) {
        User user = current(principal);

        String diaValido = HorarioService.DIAS_SEMANA.contains(dia) ? dia : null;
        String horaValida = HorarioService.HORAS_DEL_DIA.contains(horaInicio) ? horaInicio : null;
        String modalidadValida = HorarioService.CICLO_MODALIDADES.contains(modalidad) ? modalidad : null;

        if (diaValido == null || horaValida == null || modalidadValida == null) {
            return Map.of("ok", "false");
        }
        if (HorarioService.HORA_ALMUERZO_OBLIGATORIA.equals(horaValida)) {
            // El almuerzo es obligatorio para todos: no se puede editar ni con una peticion armada a mano.
            return Map.of("ok", "false", "reason", "almuerzo_obligatorio", "modalidad", HorarioService.MODALIDAD_ALMUERZO);
        }

        horarioService.marcarCelda(user, diaValido, horaValida, modalidadValida);
        return Map.of("ok", "true", "modalidad", modalidadValida);
    }

    /**
     * Convierte la lista de actividades asignadas (dia + rango de horas libre) en un mapa
     * dia -> hora -> descripcion de la tarea, para poder resaltar la celda exacta en la
     * cuadricula. Las actividades antiguas sin dia o con un rango que no se pueda leer
     * como "HH:mm - HH:mm" simplemente no se resaltan (no hay celda concreta que marcar).
     */
    private Map<String, Map<String, String>> mapaActividadesPorCelda(List<Actividad> actividades) {
        Map<String, Map<String, String>> mapa = new LinkedHashMap<>();
        for (String dia : HorarioService.DIAS_SEMANA) {
            mapa.put(dia, new LinkedHashMap<>());
        }
        for (Actividad a : actividades) {
            if (a.getDiaSemana() == null || !mapa.containsKey(a.getDiaSemana()) || a.getRangoHorario() == null) {
                continue;
            }
            String[] partes = a.getRangoHorario().split("-");
            if (partes.length != 2) {
                continue;
            }
            try {
                LocalTime inicio = LocalTime.parse(partes[0].trim());
                LocalTime fin = LocalTime.parse(partes[1].trim());
                LocalTime cursor = inicio;
                while (cursor.isBefore(fin)) {
                    String hora = cursor.toString();
                    if (HorarioService.HORAS_DEL_DIA.contains(hora)) {
                        mapa.get(a.getDiaSemana()).put(hora, a.getTareaDetalle());
                    }
                    cursor = cursor.plusHours(1);
                }
            } catch (DateTimeParseException ignored) {
                // Rango escrito a mano en un formato distinto: no se puede cruzar celda a celda.
            }
        }
        return mapa;
    }
}
