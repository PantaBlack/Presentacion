package com.imfundokahle.config;

import com.imfundokahle.model.*;
import com.imfundokahle.service.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.time.LocalTime;
import java.util.List;

/**
 * Siembra datos de demostracion al arrancar con la base de datos vacia:
 * un administrador, practicantes, profesores y alumnos, con su disponibilidad
 * semanal, algunos cursos con inscripciones, y un par de propuestas/materiales.
 * <p>
 * Las credenciales no estan fijas en el codigo: se leen de application.properties,
 * que a su vez las toma de variables de entorno (ADMIN_PASSWORD, SEED_PASSWORD).
 * La base H2 es en memoria y se recrea en cada arranque (ddl-auto=create-drop),
 * por eso el valor por defecto es fijo en vez de generarse al azar cada vez:
 * de lo contrario habria que leer el log en cada reinicio solo para poder entrar.
 */
@Component
public class DataInitializer implements CommandLineRunner {

    private static final Logger log = LoggerFactory.getLogger(DataInitializer.class);

    /** Una persona a sembrar: nombre, apellido y correo ya definidos explicitamente. */
    private record Seed(String firstName, String lastName, String email) {
    }

    private static final List<Seed> PRACTICANTES = List.of(
            new Seed("Alvaro", "Roca", "alvaro.roca@imfundo.org"),
            new Seed("Claudia", "Barcelli", "claudia.barcelli@imfundo.org"),
            new Seed("Anderson", "Larios", "anderson.larios@imfundo.org"),
            new Seed("Briana", "Montoya", "briana.montoya@imfundo.org"),
            new Seed("Gianino", "Naranjo", "gianino.naranjo@imfundo.org"),
            new Seed("Yimmy", "Diaz", "yimmy.diaz@imfundo.org"),
            new Seed("Luis", "Mendoza", "luis.mendoza@imfundo.org"),
            new Seed("Camila", "Vargas", "camila.vargas@imfundo.org"),
            new Seed("Diego", "Fernandez", "diego.fernandez@imfundo.org"),
            new Seed("Valeria", "Castillo", "valeria.castillo@imfundo.org"),
            new Seed("Mateo", "Suarez", "mateo.suarez@imfundo.org"),
            new Seed("Sofia", "Rojas", "sofia.rojas@imfundo.org"),
            new Seed("Joaquin", "Silva", "joaquin.silva@imfundo.org")
    );

    private static final List<Seed> PROFESORES = List.of(
            new Seed("Maria", "Gonzalez", "maria.gonzalez@imfundo.org"),
            new Seed("Jean", "Dupont", "jean.dupont@imfundo.org"),
            new Seed("Roberto", "Gomez", "roberto.gomez@imfundo.org"),
            new Seed("Ana", "Villanueva", "ana.villanueva@imfundo.org"),
            new Seed("Pedro", "Pascal", "pedro.pascal@imfundo.org"),
            new Seed("Carmen", "Salinas", "carmen.salinas@imfundo.org"),
            new Seed("Miguel", "Trauco", "miguel.trauco@imfundo.org"),
            new Seed("Rosa", "Dominguez", "rosa.dominguez@imfundo.org"),
            new Seed("Jorge", "Chavez", "jorge.chavez@imfundo.org"),
            new Seed("Elena", "Ramos", "elena.ramos@imfundo.org"),
            new Seed("Fernando", "Alonso", "fernando.alonso@imfundo.org"),
            new Seed("Patricia", "Santos", "patricia.santos@imfundo.org"),
            new Seed("Ricardo", "Palma", "ricardo.palma@imfundo.org"),
            new Seed("Monica", "Galindo", "monica.galindo@imfundo.org"),
            new Seed("Hugo", "Sanchez", "hugo.sanchez@imfundo.org"),
            new Seed("Teresa", "Cruz", "teresa.cruz@imfundo.org"),
            new Seed("Victor", "Caceres", "victor.caceres@imfundo.org"),
            new Seed("Blanca", "Varela", "blanca.varela@imfundo.org"),
            new Seed("Arturo", "Vidal", "arturo.vidal@imfundo.org"),
            new Seed("Natalia", "Malaga", "natalia.malaga@imfundo.org")
    );

    private static final List<Seed> ALUMNOS = List.of(
            new Seed("Lucia", "Ramirez", "lucia.ramirez@imfundo.org"),
            new Seed("Carlos", "Torres", "carlos.torres@imfundo.org"),
            new Seed("Andrea", "Luna", "andrea.luna@imfundo.org"),
            new Seed("Sebastian", "Arce", "sebastian.arce@imfundo.org"),
            new Seed("Daniela", "Vega", "daniela.vega@imfundo.org"),
            new Seed("Alejandro", "Gomez", "alejandro.gomez@imfundo.org"),
            new Seed("Victoria", "Paz", "victoria.paz@imfundo.org"),
            new Seed("Gabriel", "Flores", "gabriel.flores@imfundo.org"),
            new Seed("Gabriela", "Mendez", "gabriela.mendez@imfundo.org"),
            new Seed("Tomas", "Aquino", "tomas.aquino@imfundo.org"),
            new Seed("Mariana", "Costa", "mariana.costa@imfundo.org"),
            new Seed("Nicolas", "Peña", "nicolas.pena@imfundo.org"),
            new Seed("Valentina", "Castro", "valentina.castro@imfundo.org"),
            new Seed("Rodrigo", "Aliaga", "rodrigo.aliaga@imfundo.org"),
            new Seed("Ximena", "Morales", "ximena.morales@imfundo.org"),
            new Seed("Alonso", "Reyes", "alonso.reyes@imfundo.org"),
            new Seed("Renata", "Pineda", "renata.pineda@imfundo.org"),
            new Seed("Eduardo", "Blanco", "eduardo.blanco@imfundo.org"),
            new Seed("Antonella", "Rios", "antonella.rios@imfundo.org"),
            new Seed("Leonardo", "Ortiz", "leonardo.ortiz@imfundo.org"),
            new Seed("Fatima", "Cruz", "fatima.cruz@imfundo.org"),
            new Seed("Mauricio", "Soto", "mauricio.soto@imfundo.org"),
            new Seed("Carolina", "Herrera", "carolina.herrera@imfundo.org"),
            new Seed("Simon", "Bolivar", "simon.bolivar@imfundo.org"),
            new Seed("Juliana", "Osorio", "juliana.osorio@imfundo.org"),
            new Seed("Benjamin", "Franco", "benjamin.franco@imfundo.org"),
            new Seed("Paula", "Medina", "paula.medina@imfundo.org"),
            new Seed("Lucas", "Navarro", "lucas.navarro@imfundo.org"),
            new Seed("Romina", "Paredes", "romina.paredes@imfundo.org"),
            new Seed("Emilio", "Carrillo", "emilio.carrillo@imfundo.org"),
            new Seed("Luciana", "Vidal", "luciana.vidal@imfundo.org"),
            new Seed("Hector", "Lavoe", "hector.lavoe@imfundo.org"),
            new Seed("Samantha", "Campos", "samantha.campos@imfundo.org"),
            new Seed("Andres", "Wiese", "andres.wiese@imfundo.org"),
            new Seed("Melissa", "Loza", "melissa.loza@imfundo.org")
    );

    private final UserService userService;
    private final ScheduleService scheduleService;
    private final ProposalService proposalService;
    private final MaterialService materialService;
    private final HorarioService horarioService;

    @Value("${app.seed.admin-email}")
    private String adminEmail;

    @Value("${app.seed.admin-password}")
    private String adminPassword;

    @Value("${app.seed.demo-password}")
    private String demoPassword;

    @Value("${app.seed.demo-users-enabled:true}")
    private boolean demoUsersEnabled;

    public DataInitializer(UserService userService, ScheduleService scheduleService,
                           ProposalService proposalService, MaterialService materialService,
                           HorarioService horarioService) {
        this.userService = userService;
        this.scheduleService = scheduleService;
        this.proposalService = proposalService;
        this.materialService = materialService;
        this.horarioService = horarioService;
    }

    @Override
    public void run(String... args) {
        if (userService.countAll() > 0) {
            return; // Ya se sembro antes: no duplicar datos.
        }

        sembrarAdmin();
        if (!demoUsersEnabled) {
            return;
        }

        List<User> practicantes = crearUsuarios(PRACTICANTES, Role.PRACTICANTE);
        List<User> profesores = crearUsuarios(PROFESORES, Role.TEACHER);
        List<User> alumnos = crearUsuarios(ALUMNOS, Role.STUDENT);

        sembrarDisponibilidadPracticantes(practicantes);
        sembrarDisponibilidadProfesores(profesores);
        sembrarDisponibilidadAlumnos(alumnos);
        sembrarCursosEInscripciones(profesores, alumnos);
        sembrarPropuestasYMateriales(profesores);
    }

    /** Cuenta administradora inicial (unica, definida por configuracion). */
    private void sembrarAdmin() {
        userService.createUser("Admin", "Viva Idiomas", adminEmail, adminPassword, Role.ADMIN);
        log.warn("=================================================================");
        log.warn(" Cuenta ADMIN lista.  Correo: {}", adminEmail);
        log.warn(" Define ADMIN_PASSWORD en el entorno antes de desplegar en un");
        log.warn(" servidor real: la contrasena por defecto NO es segura ahi.");
        log.warn("=================================================================");
    }

    /** Crea todas las personas de una lista con el mismo rol y la misma contrasena de demo. */
    private List<User> crearUsuarios(List<Seed> personas, Role role) {
        return personas.stream()
                .map(p -> userService.createUser(p.firstName(), p.lastName(), p.email(), demoPassword, role))
                .toList();
    }

    // ====================================================================================
    // Disponibilidad semanal (celda a celda, en bloques de una hora)
    // ====================================================================================

    private void sembrarDisponibilidadPracticantes(List<User> practicantes) {
        // Equipo de manana
        for (User p : practicantes.subList(0, 4)) {
            crearDisponibilidad(p, "LUNES", "09:00", "13:00", "VIRTUAL");
            crearDisponibilidad(p, "LUNES", "13:00", "14:00", "ALMUERZO");
            crearDisponibilidad(p, "MARTES", "09:00", "13:00", "PRESENCIAL");
            crearDisponibilidad(p, "MIERCOLES", "14:00", "18:00", "VIRTUAL");
            crearDisponibilidad(p, "JUEVES", "09:00", "13:00", "PRESENCIAL");
        }
        // Equipo de tarde
        for (User p : practicantes.subList(4, 9)) {
            crearDisponibilidad(p, "LUNES", "14:00", "18:00", "PRESENCIAL");
            crearDisponibilidad(p, "MARTES", "13:00", "14:00", "ALMUERZO");
            crearDisponibilidad(p, "MARTES", "14:00", "18:00", "VIRTUAL");
            crearDisponibilidad(p, "JUEVES", "14:00", "18:00", "PRESENCIAL");
            crearDisponibilidad(p, "VIERNES", "09:00", "13:00", "VIRTUAL");
        }
        // Equipo mixto
        for (User p : practicantes.subList(9, 13)) {
            crearDisponibilidad(p, "MIERCOLES", "09:00", "13:00", "PRESENCIAL");
            crearDisponibilidad(p, "MIERCOLES", "13:00", "14:00", "ALMUERZO");
            crearDisponibilidad(p, "VIERNES", "14:00", "18:00", "VIRTUAL");
        }
    }

    private void sembrarDisponibilidadProfesores(List<User> profesores) {
        for (User pr : profesores.subList(0, 7)) {
            crearDisponibilidad(pr, "LUNES", "08:00", "12:00", "VIRTUAL");
            crearDisponibilidad(pr, "MIERCOLES", "14:00", "18:00", "PRESENCIAL");
            crearDisponibilidad(pr, "VIERNES", "13:00", "14:00", "ALMUERZO");
        }
        for (User pr : profesores.subList(7, 14)) {
            crearDisponibilidad(pr, "MARTES", "09:00", "13:00", "PRESENCIAL");
            crearDisponibilidad(pr, "JUEVES", "14:00", "18:00", "VIRTUAL");
            crearDisponibilidad(pr, "LUNES", "13:00", "14:00", "ALMUERZO");
        }
        for (User pr : profesores.subList(14, 20)) {
            crearDisponibilidad(pr, "MIERCOLES", "08:00", "12:00", "VIRTUAL");
            crearDisponibilidad(pr, "VIERNES", "09:00", "13:00", "PRESENCIAL");
            crearDisponibilidad(pr, "JUEVES", "13:00", "14:00", "ALMUERZO");
        }
    }

    /** Horarios de tarde predominantes, alternando dos franjas segun la posicion en la lista. */
    private void sembrarDisponibilidadAlumnos(List<User> alumnos) {
        for (int i = 0; i < alumnos.size(); i++) {
            User a = alumnos.get(i);
            if (i % 2 == 0) {
                crearDisponibilidad(a, "LUNES", "16:00", "18:00", "VIRTUAL");
                crearDisponibilidad(a, "MIERCOLES", "16:00", "18:00", "VIRTUAL");
            } else {
                crearDisponibilidad(a, "MARTES", "17:00", "19:00", "PRESENCIAL");
                crearDisponibilidad(a, "JUEVES", "17:00", "19:00", "PRESENCIAL");
            }
        }
    }

    // ====================================================================================
    // Cursos oficiales, inscripciones, propuestas y materiales
    // ====================================================================================

    private void sembrarCursosEInscripciones(List<User> profesores, List<User> alumnos) {
        Schedule h1 = crearHorario(profesores.get(0), DayOfWeekEnum.LUNES, "09:00", "10:30",
                "Ingles Basico A1", Language.ENGLISH, "Nivel inicial.", 15);
        Schedule h2 = crearHorario(profesores.get(1), DayOfWeekEnum.MIERCOLES, "15:00", "16:30",
                "Frances B1", Language.FRENCH, "Intermedio.", 15);
        Schedule h3 = crearHorario(profesores.get(4), DayOfWeekEnum.VIERNES, "10:00", "11:30",
                "Espanol Avanzado", Language.SPANISH, "Avanzado.", 20);
        Schedule h4 = crearHorario(profesores.get(9), DayOfWeekEnum.JUEVES, "09:00", "12:00",
                "Ingles Intensivo", Language.ENGLISH, "Bootcamp.", 20);

        // Repartir a los 35 alumnos en las 4 clases: 10 + 10 + 10 + 5
        inscribirRango(alumnos, 0, 10, h1);
        inscribirRango(alumnos, 10, 20, h2);
        inscribirRango(alumnos, 20, 30, h3);
        inscribirRango(alumnos, 30, 35, h4);
    }

    private void inscribirRango(List<User> alumnos, int desde, int hasta, Schedule schedule) {
        for (User alumno : alumnos.subList(desde, hasta)) {
            scheduleService.enroll(alumno, schedule);
        }
    }

    private void sembrarPropuestasYMateriales(List<User> profesores) {
        crearPropuesta(profesores.get(0), ProposalType.ACADEMIC, "Taller intensivo",
                "Propongo un taller los jueves.", ProposalStatus.PENDING, null);
        crearPropuesta(profesores.get(5), ProposalType.CURRICULAR, "Nuevo libro",
                "Actualizar material de B2.", ProposalStatus.APPROVED, "Aprobado para 2027.");

        crearMaterial(profesores.get(1), "Guia Vocabulario", "PDF interactivo.",
                MaterialCategory.GUIDE, Language.FRENCH, "https://link.com");
        crearMaterial(profesores.get(9), "Podcast Listening", "Audio para practicar.",
                MaterialCategory.VIDEO, Language.ENGLISH, "https://link.com/audio");
    }

    // ====================================================================================
    // Metodos auxiliares de bajo nivel
    // ====================================================================================

    private void crearDisponibilidad(User user, String dia, String horaInicioStr, String horaFinStr, String modalidad) {
        LocalTime inicio = LocalTime.parse(horaInicioStr);
        LocalTime fin = LocalTime.parse(horaFinStr);

        while (inicio.isBefore(fin)) {
            String horaFormateada = inicio.toString();
            String horaFinFormateada = inicio.plusHours(1).toString();
            horarioService.guardarOActualizarCelda(user, dia, horaFormateada, horaFinFormateada, modalidad);
            inicio = inicio.plusHours(1);
        }
    }

    private Schedule crearHorario(User teacher, DayOfWeekEnum day, String start, String end,
                                  String subject, Language lang, String desc, int max) {
        Schedule s = new Schedule();
        s.setTeacher(teacher);
        s.setDayOfWeek(day);
        s.setStartTime(LocalTime.parse(start));
        s.setEndTime(LocalTime.parse(end));
        s.setSubject(subject);
        s.setLanguage(lang);
        s.setDescription(desc);
        s.setMaxStudents(max);
        return scheduleService.save(s);
    }

    private void crearPropuesta(User teacher, ProposalType type, String title, String desc,
                                ProposalStatus status, String comment) {
        Proposal p = new Proposal();
        p.setTeacher(teacher);
        p.setType(type);
        p.setTitle(title);
        p.setDescription(desc);
        p.setStatus(status);
        p.setAdminComment(comment);
        proposalService.save(p);
    }

    private void crearMaterial(User teacher, String title, String desc, MaterialCategory cat,
                               Language lang, String link) {
        Material m = new Material();
        m.setTeacher(teacher);
        m.setTitle(title);
        m.setDescription(desc);
        m.setCategory(cat);
        m.setLanguage(lang);
        m.setExternalLink(link);
        materialService.save(m);
    }
}

