package com.imfundokahle.controller;

import com.imfundokahle.model.ProposalStatus;
import com.imfundokahle.model.Role;
import com.imfundokahle.service.MaterialService;
import com.imfundokahle.service.ScheduleService;
import com.imfundokahle.service.UserService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

/**
 * Controlador de la pagina publica de inicio (landing page).
 */
@Controller
public class HomeController {

    private final UserService userService;
    private final ScheduleService scheduleService;
    private final MaterialService materialService;

    public HomeController(UserService userService, ScheduleService scheduleService,
                          MaterialService materialService) {
        this.userService = userService;
        this.scheduleService = scheduleService;
        this.materialService = materialService;
    }

    @GetMapping({"/", "/index"})
    public String index(Model model) {
        // Estadisticas publicas animadas
        model.addAttribute("totalTeachers", userService.countByRole(Role.TEACHER));
        model.addAttribute("totalStudents", userService.countByRole(Role.STUDENT));
        model.addAttribute("totalClasses", scheduleService.countActiveSchedules());
        model.addAttribute("totalMaterials", materialService.countAll());
        return "index";
    }
}
