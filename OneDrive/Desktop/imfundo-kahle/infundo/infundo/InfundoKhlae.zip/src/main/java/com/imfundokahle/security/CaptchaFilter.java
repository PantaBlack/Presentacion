package com.imfundokahle.security;

import com.imfundokahle.service.CaptchaService;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;

/**
 * Filtro que valida el CAPTCHA matematico ANTES de que Spring Security
 * procese el inicio de sesion. Si el CAPTCHA es incorrecto, redirige de
 * vuelta al formulario de login con un error.
 * <p>
 * La validacion es sin estado (ver {@link CaptchaService}): no depende de
 * que la sesion HTTP siga teniendo el mismo valor que cuando se mostro la
 * pregunta, asi que no falla por tener otra pestana abierta, una recarga de
 * fondo o un reinicio del servidor entre medio.
 */
public class CaptchaFilter extends OncePerRequestFilter {

    private final CaptchaService captchaService;

    public CaptchaFilter(CaptchaService captchaService) {
        this.captchaService = captchaService;
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request,
                                    HttpServletResponse response,
                                    FilterChain filterChain)
            throws ServletException, IOException {

        // Solo interceptar el POST de inicio de sesion
        if ("POST".equalsIgnoreCase(request.getMethod())
                && "/auth/login".equals(request.getServletPath())) {

            String captchaAnswer = request.getParameter("captchaAnswer");
            String captchaToken = request.getParameter("captchaToken");
            if (!captchaService.validate(captchaAnswer, captchaToken)) {
                response.sendRedirect(request.getContextPath() + "/auth/login?captchaError=true");
                return;
            }
        }

        filterChain.doFilter(request, response);
    }
}
