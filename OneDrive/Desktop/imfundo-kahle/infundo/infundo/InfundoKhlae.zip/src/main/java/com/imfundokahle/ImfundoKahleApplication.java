package com.imfundokahle;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Clase principal de arranque de la aplicacion Imfundo Kahle.
 * Ejecuta el contenedor Spring Boot con Tomcat embebido.
 */
@SpringBootApplication
public class ImfundoKahleApplication {

    public static void main(String[] args) {
        SpringApplication.run(ImfundoKahleApplication.class, args);
    }
}
