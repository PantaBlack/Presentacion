package com.imfundokahle.service;

import com.imfundokahle.model.Actividad;
import java.util.List;

public interface ActividadService {
    List<Actividad> obtenerTodasLasActividades();
    Actividad registrarNuevaActividad(Actividad actividad);
    Actividad buscarPorId(Long id);
    Actividad cambiarEstado(Long id, String nuevoEstado);
    void borrarActividad(Long id);

    /** Resumen de las actividades asignadas a una persona, por su nombre completo. */
    ActividadResumen obtenerResumenPara(String nombreCompleto);
}