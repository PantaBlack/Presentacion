package com.imfundokahle.repository;

import com.imfundokahle.model.Actividad;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;


public interface ActividadRepository extends JpaRepository<Actividad, Long> {
    
    // Spring Data JPA crea la consulta SQL automáticamente basándose en el nombre del método
    List<Actividad> findAllByOrderByCreadoEnDesc();
    
    List<Actividad> findByEstadoActualOrderByCreadoEnDesc(String estadoActual);

    List<Actividad> findByRolOrderByCreadoEnDesc(String rol);

    // Actividades asignadas a una persona (se cruzan por nombre completo, sin distinguir mayusculas)
    List<Actividad> findByNombreAsignadoIgnoreCaseOrderByCreadoEnDesc(String nombreAsignado);
}