package com.imfundokahle.controller;

import com.imfundokahle.model.User;
import com.imfundokahle.service.ActividadResumen;
import com.imfundokahle.service.ActividadService;
import com.imfundokahle.service.UserService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.security.Principal;

/**
 * Controlador del portal de practicante (/practicante/**).
 * Muestra las actividades que el administrador le ha asignado
 * y el resumen de horas planificadas.
 */
@Controller
@RequestMapping("/practicante")
public class PracticanteController {

    private final ActividadService actividadService;
    private final UserService userService;

    public PracticanteController(ActividadService actividadService, UserService userService) {
        this.actividadService = actividadService;
        this.userService = userService;
    }

    @GetMapping({"", "/", "/dashboard"})
    public String dashboard(Principal principal, Model model) {
        model.addAttribute("title", "Panel de Practicante");
        model.addAttribute("activeTab", "dashboard");

        User user = userService.findByEmail(principal.getName()).orElseThrow();
        ActividadResumen resumen = actividadService.obtenerResumenPara(user.getFullName());

        model.addAttribute("actividades", resumen.actividades());
        model.addAttribute("totalActividades", resumen.total());
        model.addAttribute("pendientes", resumen.pendientes());
        model.addAttribute("enCurso", resumen.enCurso());
        model.addAttribute("completadas", resumen.completadas());
        model.addAttribute("horasPlanificadas", resumen.horasPlanificadas());
        model.addAttribute("horasCompletadas", resumen.horasCompletadas());

        return "practicante/dashboard";
    }
}
