package com.imfundokahle.repository;

import com.imfundokahle.model.Language;
import com.imfundokahle.model.Material;
import com.imfundokahle.model.MaterialCategory;
import com.imfundokahle.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

/** Repositorio de materiales. */
public interface MaterialRepository extends JpaRepository<Material, Long> {
    List<Material> findByTeacherOrderByCreatedAtDesc(User teacher);
    List<Material> findByLanguage(Language language);
    List<Material> findByCategory(MaterialCategory category);
    List<Material> findAllByOrderByCreatedAtDesc();
    long countByTeacher(User teacher);
}
