package com.imfundokahle.service;

import com.imfundokahle.model.Material;
import com.imfundokahle.model.MaterialVisibility;
import com.imfundokahle.model.Role;
import com.imfundokahle.model.User;
import com.imfundokahle.repository.MaterialRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

/**
 * Servicio de materiales educativos.
 */
@Service
public class MaterialService {

    private final MaterialRepository materialRepository;

    public MaterialService(MaterialRepository materialRepository) {
        this.materialRepository = materialRepository;
    }

    @Transactional
    public Material save(Material material) {
        return materialRepository.save(material);
    }

    public Material findById(Long id) {
        return materialRepository.findById(id).orElse(null);
    }

    public List<Material> findAll() {
        return materialRepository.findAllByOrderByCreatedAtDesc();
    }

    public List<Material> findByTeacher(User teacher) {
        return materialRepository.findByTeacherOrderByCreatedAtDesc(teacher);
    }

    /** Materiales visibles para un alumno: todo salvo lo marcado "solo para profesores". */
    public List<Material> findVisibleToStudents() {
        return findAll().stream()
                .filter(m -> m.getVisibility() != MaterialVisibility.TEACHERS_ONLY)
                .collect(Collectors.toList());
    }

    public long countByTeacher(User teacher) {
        return materialRepository.countByTeacher(teacher);
    }

    public long countAll() {
        return materialRepository.count();
    }

    @Transactional
    public void delete(Long id) {
        materialRepository.deleteById(id);
    }

    /**
     * Si el usuario puede ver (y por lo tanto descargar) este material: el dueño y
     * el admin siempre pueden; el resto depende de la visibilidad configurada.
     */
    public boolean esVisiblePara(Material material, User usuario) {
        if (usuario.getRole() == Role.ADMIN) {
            return true;
        }
        if (material.getTeacher().getId().equals(usuario.getId())) {
            return true;
        }
        if (material.getVisibility() == MaterialVisibility.TEACHERS_ONLY) {
            return usuario.getRole() == Role.TEACHER;
        }
        return true;
    }
}
