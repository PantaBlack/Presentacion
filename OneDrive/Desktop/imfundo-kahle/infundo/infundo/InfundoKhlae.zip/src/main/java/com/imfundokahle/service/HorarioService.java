package com.imfundokahle.service;

import com.imfundokahle.model.Horario;
import com.imfundokahle.model.User;
import com.imfundokahle.repository.HorarioRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Service
public class HorarioService {

    /** Modalidad que representa una celda vacia: no se guarda fila, se borra si existia. */
    public static final String LIBRE = "LIBRE";

    /** Franja horaria del centro: 08:00 a 20:00, en bloques de una hora. */
    public static final List<String> HORAS_DEL_DIA = List.of(
            "08:00", "09:00", "10:00", "11:00", "12:00", "13:00", "14:00",
            "15:00", "16:00", "17:00", "18:00", "19:00"
    );

    /** Dias habiles del centro, en el orden en que se muestran. */
    public static final List<String> DIAS_SEMANA = List.of(
            "LUNES", "MARTES", "MIERCOLES", "JUEVES", "VIERNES"
    );

    /** Modalidades validas para una celda, en el orden en que se van alternando al hacer clic. */
    public static final List<String> CICLO_MODALIDADES = List.of(LIBRE, "PRESENCIAL", "VIRTUAL", "ALMUERZO");

    /**
     * Hora de almuerzo obligatoria para todo el mundo, todos los dias: nadie
     * la puede editar ni el admin la puede usar para asignar una tarea.
     * Se aplica siempre en cada lectura, sin importar lo que haya guardado
     * en la base de datos.
     */
    public static final String HORA_ALMUERZO_OBLIGATORIA = "13:00";
    public static final String MODALIDAD_ALMUERZO = "ALMUERZO";

    private final HorarioRepository horarioRepository;

    public HorarioService(HorarioRepository horarioRepository) {
        this.horarioRepository = horarioRepository;
    }

    @Transactional(readOnly = true)
    public List<Horario> obtenerHorarioPorColaborador(User colaborador) {
        return horarioRepository.findByColaborador(colaborador);
    }

    /**
     * El horario real de un colaborador, pero con la hora de almuerzo obligatoria
     * ya forzada en los 5 dias (reemplazando cualquier otra cosa que hubiera ahi).
     * Este es el horario "verdadero" que debe verse en cualquier pantalla: la
     * cuadricula propia, la del admin al asignar tareas, y las vistas de inspeccion.
     */
    @Transactional(readOnly = true)
    public List<Horario> obtenerHorarioEfectivo(User colaborador) {
        List<Horario> efectivo = new ArrayList<>();
        for (Horario h : obtenerHorarioPorColaborador(colaborador)) {
            if (!HORA_ALMUERZO_OBLIGATORIA.equals(h.getHoraInicio())) {
                efectivo.add(h);
            }
        }
        for (String dia : DIAS_SEMANA) {
            efectivo.add(new Horario(colaborador, dia, HORA_ALMUERZO_OBLIGATORIA,
                    siguienteHora(HORA_ALMUERZO_OBLIGATORIA), MODALIDAD_ALMUERZO));
        }
        return efectivo;
    }

    /**
     * Disponibilidad de un colaborador como mapa dia -> hora -> modalidad,
     * listo para pintar directamente en una cuadricula (sin buscar en listas
     * dentro de la plantilla). Las celdas sin dato no aparecen en el mapa,
     * salvo la hora de almuerzo obligatoria, que siempre aparece.
     */
    @Transactional(readOnly = true)
    public Map<String, Map<String, String>> obtenerMapaSemanal(User colaborador) {
        Map<String, Map<String, String>> mapa = new LinkedHashMap<>();
        for (String dia : DIAS_SEMANA) {
            mapa.put(dia, new LinkedHashMap<>());
        }
        for (Horario h : obtenerHorarioEfectivo(colaborador)) {
            mapa.computeIfAbsent(h.getDiaSemana(), d -> new LinkedHashMap<>())
                    .put(h.getHoraInicio(), h.getModalidad());
        }
        return mapa;
    }

    @Transactional
    public Horario guardarOActualizarCelda(User colaborador, String diaSemana, String horaInicio, String horaFin, String modalidad) {
        // Buscar si el usuario ya tiene una celda registrada en ese día y a esa hora
        Optional<Horario> celdaExistente = horarioRepository.findByColaboradorAndDiaSemanaAndHoraInicio(colaborador, diaSemana, horaInicio);

        if (celdaExistente.isPresent()) {
            // Si ya existe, solo actualizamos la modalidad (ej. pasó de VIRTUAL a PRESENCIAL)
            Horario horario = celdaExistente.get();
            horario.setModalidad(modalidad);
            return horarioRepository.save(horario);
        } else {
            // Si no existe, creamos una celda nueva
            Horario nuevoHorario = new Horario(colaborador, diaSemana, horaInicio, horaFin, modalidad);
            return horarioRepository.save(nuevoHorario);
        }
    }

    /**
     * Actualiza una celda de la propia disponibilidad: si la modalidad es LIBRE
     * borra la celda (para no dejar filas vacias en la base de datos), y si no,
     * la crea o actualiza cubriendo exactamente una hora.
     * <p>
     * La hora de almuerzo obligatoria nunca se puede editar (ni desde la
     * cuadricula propia ni con una peticion armada a mano): esta linea es la
     * que de verdad protege la regla, la del frontend es solo comodidad visual.
     */
    @Transactional
    public void marcarCelda(User colaborador, String diaSemana, String horaInicio, String modalidad) {
        if (HORA_ALMUERZO_OBLIGATORIA.equals(horaInicio)) {
            return;
        }
        if (LIBRE.equals(modalidad)) {
            horarioRepository.deleteByColaboradorAndDiaSemanaAndHoraInicio(colaborador, diaSemana, horaInicio);
            return;
        }
        String horaFin = siguienteHora(horaInicio);
        guardarOActualizarCelda(colaborador, diaSemana, horaInicio, horaFin, modalidad);
    }

    private String siguienteHora(String horaInicio) {
        return java.time.LocalTime.parse(horaInicio).plusHours(1).toString();
    }

    @Transactional
    public void resetearHorario(User colaborador) {
        horarioRepository.deleteByColaborador(colaborador);
    }
}
